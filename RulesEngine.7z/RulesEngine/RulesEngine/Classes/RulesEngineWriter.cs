﻿using RulesEngine.User_Interface;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace RulesEngine.Classes
{
    class RulesEngineWriter : IRulesEngineWriter
    {
        private static RulesEngineWriter _instance = null;
        private readonly string _filePath;
     
        private RulesEngineWriter(string filePath)
        {
            _filePath = filePath;
        }

        public static RulesEngineWriter GetInstance(string filePath)
        {
            if (_instance == null)
                _instance = new RulesEngineWriter(filePath);
            return _instance;
        }

        /// Method to save voilated data list
        public void SaveVoilatedRules(List<string> voilatedRuleDataList)
        {
            Task.Factory.StartNew(() => SaveVoilatedOutPutToFile(voilatedRuleDataList)).Wait();
        }

        /// Method to save extracted voilated signal names list in text file using the rules defined by user
        private void SaveVoilatedOutPutToFile(List<string> voilatedRuleDataList)
        {
            if (File.Exists(_filePath)) File.Delete(_filePath);
            using (StreamWriter sw = new StreamWriter(_filePath))
            {
                foreach (string voilatedRule in voilatedRuleDataList)
                {
                    sw.WriteLine(voilatedRule);
                }
            }
        }
    }
}