﻿using System.Collections.Generic;

namespace RulesEngine.User_Interface
{
    interface IRulesEngineWriter
    {
        void SaveVoilatedRules(List<string> voilatedRuleDataList);
    }
}